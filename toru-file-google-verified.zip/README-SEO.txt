Google検索対応版

追加済み:
- SEO向け title / description
- index,follow
- SoftwareApplication / WebSite 構造化データ
- Open Graph / favicon
- 検索ニーズ向け本文
- /upload-error.html
- /image-5mb.html
- /robots.txt（Vercel上で自動生成）
- /sitemap.xml（Vercel上で自動生成）
- 内部リンク
- X-Robots-Tag

公開後に必要:
1. Google Search Consoleへ公開URLを登録
2. sitemap.xml を送信
3. URL検査でトップページの「インデックス登録をリクエスト」
4. 数日〜数週間待つ（掲載・順位は保証されません）
