module.exports = (req,res) => {
  const host = req.headers["x-forwarded-host"] || req.headers.host;
  const proto = req.headers["x-forwarded-proto"] || "https";
  res.setHeader("Content-Type","text/plain; charset=utf-8");
  res.setHeader("Cache-Control","public, max-age=3600");
  res.status(200).send(`User-agent: *
Allow: /

Sitemap: ${proto}://${host}/sitemap.xml
`);
};